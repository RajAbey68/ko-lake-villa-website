// Placeholder for AI tag logic
export function generateTagsFromImage(imagePath: string): string[] {
  return ['beach', 'sunset', 'villa']; // Default example tags
}
