import React from 'react';

export default function AdminIndex() {
  return (
    <main>
      <h1>Welcome to the Admin Panel</h1>
      <p>Please navigate to /admin/dashboard to begin.</p>
    </main>
  );
}
