import React from 'react';

export default function Dashboard() {
  return (
    <main>
      <h1>Dashboard</h1>
      <p>This is the admin dashboard. Features coming soon.</p>
    </main>
  );
}
